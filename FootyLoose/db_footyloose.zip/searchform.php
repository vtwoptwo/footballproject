<!-- (A) SEARCH FORM -->
<form method="post" action="searchform.php">
  <h1>SEARCH FOR USERS</h1>
  <input type="text" name="search" required/>
  <input type="submit" value="Search"/>
</form>

<?php

if (isset($_POST["search"])) {
  // (B1) SEARCH FOR USERS
  require "search.php";


  if (count($results) > 0) { foreach ($results as $r) {
    printf("<div>%s - %s</div>", $r["ID"], $r["first_name"]);
  }} else { echo "No results found"; }
}
?>