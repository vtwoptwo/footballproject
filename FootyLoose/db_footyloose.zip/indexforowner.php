

<!DOCTYPE html>
<html>
<head>
    <meta name ="viewport" content ="with=device-width, initial-scale=1.0">
    <title> Managers Homepage </title>
    <link rel="stylesheet" href="style_userindex.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,200;0,500;0,700;1,900&display=swap" rel="stylesheet">

<style>
#x {
  
  border-collapse: collapse;
  width: 100%;
}

#x td, #x th {
  border: 2px  #fff;
  padding: 8px;
}

#x tr:nth-child(even){background-color: #fff;}

#x tr:hover {background-color:#fff;}

#x th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #0e3163;
  color: white;
}

</style>
</head>

    <body>
<section class="header">
    <nav>
        <a href="index.php"><img src="images/logo.PNG"></a>
        <div class="navbar"></div>
            <ul>
			<li><a href = "#searchplayerpa">SEARCH PLAYER</a></li>
            <li><a href = "#searchmatches">SEARCH MATCH</a></li>
            <li><a href = "#searchevent">SEARCH EVENT</a></li>
            <li><a href = "#searchteams">SEARCH TEAM</a></li>
            <li><a href = "#searchusers">SEARCH USER</a></li>
                
            </ul>
    </nav>

<div class="textbox">
	<h1>FootyLoose for Owners</h1>
	<p>Welcome to the Soccer database. Please select the table you want to view.</p>
    <a href="aboutus.php" class="hp-btn"> About FootyLoose</a>
</div>

</section>

<section class="search">
    <div class="searchplayerpa" id="searchplayerpa">
            <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4>Search for a Player</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="aboves">

                                            <form action="" method="GET">
                                                <div class="input-group">
                                                    <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search data">
                                                    <button type="submit" class="btnsearch">Search</button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="card mt-4">
                                <div class="card-body-blue">
                                    <table class="table table-all" id="x">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>First Name</th>
                                                <th>Middle Name</th>
                                                <th>Last Name</th>
                                                <th>Birth Date</th>
                                                <th>Height</th>
                                                <th>Weight</th>
                                                <th>Current Team</th>
                                                <th>Previous Team</th>
                                                <th>Experience</th>
                                                <th>Start Date</th>
                                                <th>End Date</th>
                                                <th>Binding Conditions</th>
                                                <th>Occupation</th>
                                                <th>Institution</th>
                                                <th>Hobbies</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $con = mysqli_connect("localhost","root","","Soccer");

                                                if(isset($_GET['search']))
                                                {
                                                    $filtervalues = $_GET['search'];
                                                    $query = "SELECT * FROM PLAYERPA WHERE CONCAT(first_name,surname,birth_date) LIKE '%$filtervalues%' ";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {
                                                        foreach($query_run as $items)
                                                        {
                                                            ?>
                                                            <tr>
                                                                <td><?= $items['ID']; ?></td>
                                                                <td><?= $items['first_name']; ?></td>
                                                                <td><?= $items['middle_name']; ?></td>
                                                                <td><?= $items['surname']; ?></td>
                                                                <td><?= $items['birth_date']; ?></td>
                                                                <td><?= $items['height']; ?></td>
                                                                <td><?= $items['weight']; ?></td>
                                                                <td><?= $items['current_team']; ?></td>
                                                                <td><?= $items['previous_team']; ?></td>
                                                                <td><?= $items['experience']; ?></td>
                                                                <td><?= $items['start_date']; ?></td>
                                                                <td><?= $items['end_data']; ?></td>
                                                                <td><?= $items['binding_condition']; ?></td>
                                                                <td><?= $items['occupation']; ?></td>
                                                                <td><?= $items['institution']; ?></td>
                                                                <td><?= $items['hobbies']; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                            <tr>
                                                                <td colspan="4">No Record Found</td>
                                                            </tr>
                                                        <?php
                                                    }
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


    <div class="searchevent" id="searchevent">
        <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mt-4">
                            <div class="card-header">
                                <h4>Search for a Specific Events from Matches</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-7" >

                                        <form action="" method="GET">
                                            <div class="input-group mb-3">
                                                <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search data">
                                                <button type="submit" class="btnsearch">Search</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="card mt-4">
                            <div class="card-body">
                                <table class="table table-all" id="x">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                           					<th>Event ID</th>
                            				<th>Match ID</th>
                            				<th>Player ID</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            $con = mysqli_connect("localhost","root","","Soccer");

                                            if(isset($_GET['search']))
                                            {
                                                $filtervalues = $_GET['search'];
                                                $query = "SELECT * FROM EVENT WHERE CONCAT(ID,Event ID,Match ID,Player ID) LIKE '%$filtervalues%' ";
                                                $query_run = mysqli_query($con, $query);

                                                if(mysqli_num_rows($query_run) > 0)
                                                {
                                                    foreach($query_run as $items)
                                                    {
                                                        ?>
                                                        <tr>
                                                            <td><?= $items['ID']; ?></td>
                                                            <td><?= $items['Event ID']; ?></td>
                                                            <td><?= $items['Match ID']; ?></td>
                                                            <td><?= $items['Player ID']; ?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                        <tr>
                                                            <td colspan="4">No Record Found</td>
                                                        </tr>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <div class="searchmatches" id="searchmatches">
        <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mt-4">
                            <div class="card-header">
                                <h4>Search for a Match</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-7">

                                        <form action="" method="GET">
                                            <div class="input-group">
                                                <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search data">
                                                <button type="submit" class="btnsearch">Search</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="card mt-4">
                            <div class="card-body">
                                <table class="table table-all" id="x">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                           					<th>Score</th>
                            				<th>Place</th>
                            				<th>Date</th>
                            				<th>Extra Time</th>
                            				<th>Penalty Shootouts</th>
                            				<th>Results</th>
                            				<th>Timings</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            $con = mysqli_connect("localhost","root","","Soccer");

                                            if(isset($_GET['search']))
                                            {
                                                $filtervalues = $_GET['search'];
                                                $query = "SELECT * FROM MATCHES WHERE CONCAT(ID,place,date) LIKE '%$filtervalues%' ";
                                                $query_run = mysqli_query($con, $query);

                                                if(mysqli_num_rows($query_run) > 0)
                                                {
                                                    foreach($query_run as $items)
                                                    {
                                                        ?>
                                                        <tr>
                                                            <td><?= $items['ID']; ?></td>
                                                            <td><?= $items['score']; ?></td>
                                                            <td><?= $items['place']; ?></td>
                                                            <td><?= $items['date']; ?></td>
                                                            <td><?= $items['extra_time']; ?></td>
                                                            <td><?= $items['penalty_shootouts']; ?></td>
                                                            <td><?= $items['win_lose_draw']; ?></td>
                                                            <td><?= $items['timings']; ?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                        <tr>
                                                            <td colspan="4">No Record Found</td>
                                                        </tr>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    <div class="searchusers" id="searchusers">
            <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mt-4">
                                <div class="card-header">
                                    <h4>Search for a User</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-7">

                                            <form action="" method="GET">
                                                <div class="input-group">
                                                    <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search data">
                                                    <button type="submit" class="btnsearch">Search</button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="card mt-4">
                                <div class="card-body">
                                    <table class="table table-all" id="x">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Username</th>
                                                <th>Title</th>
                                                <th>Created at</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                                $con = mysqli_connect("localhost","root","","Soccer");

                                                if(isset($_GET['search']))
                                                {
                                                    $filtervalues = $_GET['search'];
                                                    $query = "SELECT * FROM USERS WHERE CONCAT(id,username,title) LIKE '%$filtervalues%' ";
                                                    $query_run = mysqli_query($con, $query);

                                                    if(mysqli_num_rows($query_run) > 0)
                                                    {
                                                        foreach($query_run as $items)
                                                        {
                                                            ?>
                                                            <tr>
                                                                <td><?= $items['id']; ?></td>
                                                                <td><?= $items['username']; ?></td>
                                                                <td><?= $items['title']; ?></td>
                                                                <td><?= $items['created_at']; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                            <tr>
                                                                <td colspan="4">No Record Found</td>
                                                            </tr>
                                                        <?php
                                                    }
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    <div class="searchteams" id="searchteams">
        <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mt-4">
                            <div class="card-header">
                                <h4>Search for a Team</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-7">

                                        <form action="" method="GET">
                                            <div class="input-group">
                                                <input type="text" name="search" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search data">
                                                <button type="submit" class="btnsearch">Search</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="card mt-4">
                            <div class="card-body">
                                <table class="table table-all" id="x">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                           					<th>Name</th>
                            				<th>Address</th>
                            				<th>Ranking</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                            $con = mysqli_connect("localhost","root","","Soccer");

                                            if(isset($_GET['search']))
                                            {
                                                $filtervalues = $_GET['search'];
                                                $query = "SELECT * FROM TEAM WHERE CONCAT(ID,name,address,ranking) LIKE '%$filtervalues%' ";
                                                $query_run = mysqli_query($con, $query);

                                                if(mysqli_num_rows($query_run) > 0)
                                                {
                                                    foreach($query_run as $items)
                                                    {
                                                        ?>
                                                        <tr>
                                                            <td><?= $items['ID']; ?></td>
                                                            <td><?= $items['name']; ?></td>
                                                            <td><?= $items['address']; ?></td>
                                                            <td><?= $items['ranking']; ?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                        <tr>
                                                            <td colspan="4">No Record Found</td>
                                                        </tr>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    
</section>

<section class="info">
    <h1> With Footloose you learn how to fly! </h1>
    <p> <b> win or loose there is no try <b> </p>

</section>


</body>
</html>


