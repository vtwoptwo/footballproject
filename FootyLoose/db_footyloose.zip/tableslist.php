<!DOCTYPE html>
<html>
<head>
	<title>Soccer Database</title>
	<link rel="stylesheet" type ="text/css" href="mystyle.css">
</head>
<body>
<h1>ADministrator Page </h1>
<p>Welcome to the Soccer database. Please select the table you want to view.</p>
<ul>
	<li><a href = "administration.php">ADMINISTRATION</a></li>
	<li><a href = "matches.php">MATCH</a></li>
	<li><a href = "performance_player.php">PERFORMANCE OF PLAYER</a></li>
	<li><a href = "player.php">PLAYER</a></li>
	<li><a href = "position.php">POSITION</a></li>
	<li><a href = "team.php">TEAM</a></li>
	<li><a href = "contact.html">EVENT</a></li>
</ul>
</body>
</html>